Looking forward to learn advanced Data Structures and Algorithms?

Have a look at these topics in this folder. These topics are taken from codeforces
