This folder contains all the images used in the jupyter notebooks of **18 Dictionaries** topic.
