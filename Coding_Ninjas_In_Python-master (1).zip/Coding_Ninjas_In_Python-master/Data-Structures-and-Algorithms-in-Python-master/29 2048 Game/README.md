# 2048
This folder contains code for 2048 game created using Python
