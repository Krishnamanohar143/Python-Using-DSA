This folder contains all the images used in Graphs - 1
