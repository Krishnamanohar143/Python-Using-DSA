This repository includes all the practice problems and assignments which I've solved during the Course of Python Programming taught by Coding Ninjas. It includes 2 chapters as mentioned below.
# Introduction to Python
# Algorithms and Data Structures in Python
