##Write a program to input marks of three tests of a student (all integers). Then calculate and print the average of all test marks.



# Read input as sepcified in the question
# Print output as specified in the question
a=int(input())
b=int(input())
c=int(input())
s=a+b+c
print(s/3)
