##You are given two integers: X and N. You have to calculate X raised to power N and print it.


# Write your code here
a=int(input())
b=int(input())
print(a**b)
