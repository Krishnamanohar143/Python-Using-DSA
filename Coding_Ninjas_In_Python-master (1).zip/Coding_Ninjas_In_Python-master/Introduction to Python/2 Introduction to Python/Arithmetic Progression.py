##You are given first three entries of an arithmetic progression. You have to calculate the common difference and print it.


# Write your code here
a=int(input())
b=int(input())
c=int(input())
print(c-b)
